% This script will configure and run the simulation.
% #######################
warning off;
clc;
clear;
prepare_sim;
Lower_Speed_Limit_for_Support=6.94;
Upper_Speed_Limit_for_Support=8.3;
disp( '#######################' );

%% first simulation run
% update model parameters
disp( 'Updating model parameters for Standard bike' );


M_Driver = 70;
M_Bike = 25;
A = 0.5;
Cr = 0.006;
Cw = 1.1;
P_U = 100;
P_Max = 250;

% run simulation
SimOut = sim('ebike');

Battery_Power = SimOut.get('Battery_Power');
Energy_Total = SimOut.get('Energy_Total');
Distance = SimOut.get('Distance');
Energy_Downhill_Slope = SimOut.get('Energy_Downhill_Slope');
Energy_Air_Drag = SimOut.get('Energy_Air_Drag');
Energy_Acceleration = SimOut.get('Energy_Acceleration');
Energy_Rolling_Friction = SimOut.get('Energy_Rolling_Friction');
Energy_Downhill_Slope_percentage1 = SimOut.get('Energy_Downhill_Slope_percentage');
Energy_Air_Drag_percentage1 = SimOut.get('Energy_Air_Drag_percentage');
Energy_Acceleration_percentage1 = SimOut.get('Energy_Acceleration_percentage');
Energy_Rolling_Friction_percentage1 = SimOut.get('Energy_Rolling_Friction_percentage');
Energy_Driver= SimOut.get('Energy_Driver');
Energy_Motor = SimOut.get('Energy_Motor');
P_Driver = SimOut.get('P_Driver');  
P_Support = SimOut.get('P_Support');
Velocity = SimOut.get('Velocity');
Velocity.Data = Velocity.Data*3.6;
P_Support_Max = SimOut.get('P_Support_Max');


f1 = figure('Name','Standard bike','NumberTitle','on');
set(f1, 'Units', 'Normalized', 'Position', [0.10, 0.00, 0.80, 0.80]); 

subplot(2,2,1);
plot(Distance.Data, Battery_Power.Data); xlabel('Distance[km]'); ylabel('Battery Power [Ah]');grid on;

subplot(2,2,2);
plot(Distance.Data,Energy_Driver.Data,Distance.Data,Energy_Motor.Data); xlabel('Distance [km]'); ylabel('Energy [Wh]'); grid on; 
title('Energy Distribution among Driver and Motor');
legend('Driver', 'Motor','Location','NorthWest');

subplot(2,2,3);
plot(Distance.Data,Energy_Total.Data); ylabel('Energy Total [Wh]'); xlabel('Distance [km]'); grid on;

 subplot(2,2,4);
plot(Distance.Data,Energy_Downhill_Slope.Data,Distance.Data,Energy_Air_Drag.Data,Distance.Data,Energy_Acceleration.Data,Distance.Data,Energy_Rolling_Friction.Data); xlabel('Distance [km]'); ylabel('Energy [Wh]');
grid on;title('Energy Distribution among forces');
legend('Energy Downhill slope', 'Air Drag','Energy Acceleration','Energy Rolling Firction','Location','NorthWest');

% compute statistics from simulation result

variable = [Distance.Data Energy_Total.Data Battery_Power.Data];



%% second simulation run
% update model parameters
disp( 'Updating model parameters for racing bike' );
%prepare_sim;

M_Driver = 70;
M_Bike = 25;
A = 0.38;
Cr = 0.003;
Cw = 0.4;
P_U=100;
P_Max=250;


% run simulation
SimOut = sim('ebike');

%Store obtained variables
Battery_Power = SimOut.get('Battery_Power');  
Energy_Total = SimOut.get('Energy_Total');
Distance = SimOut.get('Distance');
Energy_Downhill_Slope = SimOut.get('Energy_Downhill_Slope');
Energy_Air_Drag = SimOut.get('Energy_Air_Drag');
Energy_Acceleration = SimOut.get('Energy_Acceleration');
Energy_Rolling_Friction = SimOut.get('Energy_Rolling_Friction');
Energy_Downhill_Slope_percentage2 = SimOut.get('Energy_Downhill_Slope_percentage');
Energy_Air_Drag_percentage2 = SimOut.get('Energy_Air_Drag_percentage');
Energy_Acceleration_percentage2 = SimOut.get('Energy_Acceleration_percentage');
Energy_Rolling_Friction_percentage2 = SimOut.get('Energy_Rolling_Friction_percentage');
Energy_Driver= SimOut.get('Energy_Driver');
Energy_Motor = SimOut.get('Energy_Motor');
P_Driver = SimOut.get('P_Driver');  
P_Support = SimOut.get('P_Support');


%
f2 = figure('Name','Racing bike','NumberTitle','on');
set(f2, 'Units', 'Normalized', 'Position', [0.10, 0.00, 0.80, 0.80]); 

subplot(2,2,1);
plot(Distance.Data, Battery_Power.Data); xlabel('Distance [km]'); ylabel('Battery Power [Ah]');grid on;

subplot(2,2,2);
plot(Distance.Data,Energy_Driver.Data,Distance.Data,Energy_Motor.Data); xlabel('Distance [km]'); ylabel('Energy [Wh]'); grid on; 
title('Energy Distribution among Driver and Motor');
legend('Driver', 'Motor','Location','NorthWest');

 subplot(2,2,3);
plot(Distance.Data,Energy_Total.Data); ylabel('Energy Total [Wh]'); xlabel('Distance [km]'); grid on;

 subplot(2,2,4);
plot(Distance.Data,Energy_Downhill_Slope.Data,Distance.Data,Energy_Air_Drag.Data,Distance.Data,Energy_Acceleration.Data,Distance.Data,Energy_Rolling_Friction.Data); xlabel('Distance [km]'); ylabel('Energy [Wh]');
grid on;title('Energy Distribution among forces');
legend('Energy Downhill slope', 'Air Drag','Energy Acceleration','Energy Rolling Firction','Location','NorthWest');



f3 = figure('Name','Standard and Racing bike Energy Distribution','NumberTitle','on');
set(f3, 'Units', 'Normalized', 'Position', [0.10, 0.00, 0.80, 0.80]); 

subplot(1,2,1);
plot(Distance.Data,Energy_Downhill_Slope_percentage1.Data,Distance.Data,Energy_Air_Drag_percentage1.Data,Distance.Data,Energy_Acceleration_percentage1.Data,Distance.Data,Energy_Rolling_Friction_percentage1.Data); xlabel('Distance [km]'); ylabel('Energy [Wh]');
grid on;title('Standard Bike');
legend('Energy Downhill slope(%)', 'Air Drag(%)','Energy Acceleration(%)','Energy Rolling Firction(%)');

subplot(1,2,2);
plot(Distance.Data,Energy_Downhill_Slope_percentage2.Data,Distance.Data,Energy_Air_Drag_percentage2.Data,Distance.Data,Energy_Acceleration_percentage2.Data,Distance.Data,Energy_Rolling_Friction_percentage2.Data); xlabel('Distance [km]'); ylabel('Energy [Wh]');
grid on;title('Racing Bike');
legend('Energy Downhill slope(%)', 'Air Drag(%)','Energy Acceleration(%)','Energy Rolling Firction(%)');


% compute statistics from simulation result
variable(:,4:5) = [Energy_Total.Data Battery_Power.Data];



%% further simulation runs
% ...
%% Display Results
%clc;

disp(sprintf('Mass of the Driver: %d \nMass of the Bike: %d ', M_Driver, M_Bike));
disp('Cr: Rolling friction coefficient     (racing tires: 0.003, Standard tires: 0.006)');
disp('Cw: Air drag coefficient             (racing bike: 0.4, Standard bike: 1.1)');
disp('A:  Frontal area of driver and bike  (racing bike: 0.38 m^2, Standard bike: 0.5 m^2)');
disp('#######################');
disp(sprintf('Total time of travel(track: %0.2f km ):  %0.0f seconds( %0.3f hours) ',track(size(track,1),const.COL_CUM_DST),Modified_Track_Data(size(Modified_Track_Data,1), const.COL_CUM_TIME),Modified_Track_Data(size(Modified_Track_Data,1), const.COL_CUM_TIME)/3600));
disp(' ');
disp('       Standard Bike                             Racing Bike');
disp('Energy Used[Wh] Battery Remaining[Ah]   Energy Used[Wh] Battery Remaning[Ah]');
disp(sprintf(' %0.3f             %0.3f                %0.3f          %0.3f ', variable(size(variable,1),2),variable(size(variable,1),3),variable(size(variable,1),4),variable(size(variable,1),5)));
disp('#######################');

temp= [Velocity.Data P_Support_Max.Data];
Velocity_and_Max_Power = unique(temp, 'rows'); 
clear temp;

f4 = figure('Name', 'Max Power considered');
set(f4, 'Units', 'Normalized', 'Position', [0.10, 0.00, 0.80, 0.80]); 
plot(Velocity_and_Max_Power(:,1),Velocity_and_Max_Power(:,2));  xlabel('Velocity [km/h]'); ylabel('Max Support Power [W]');





%% clean up workspace
disp( 'Cleaning up Workspace.' );
% clear parameters
clear;
% clear simulation output


disp( 'Done.' );
disp( '#######################' );