% This script will be used to prepare the workspace for the simulation.
%
% First, an example .gpx file will be parsed to get a matrix of gps 
% coordinates and distance information.
%
% Next, this information will be used to extend the spatial data by
% assigning a timespan to each track segment and computing derived factors
% like acceleration.
%
% The result will be stored in the variable "route" (accessible from the
% workspace).
%
% See also loadgpx, assign_speed
disp( '#######################' );
%% load track
disp( 'Loading track "track_01.gpx".' );
track = loadgpx( 'track_01.gpx' );

%% assign speed
disp( 'Assigning segment speed and computing segment timespan and acceleration.' );
Modified_Track_Data(:,const.COL_CUM_DST) = linspace(0,7,700)';
Modified_Track_Data(1,const.COL_SEG_DST) = 0.01;

for i = 2:size(Modified_Track_Data, 1)
    Modified_Track_Data(i,const.COL_SEG_DST) =  Modified_Track_Data(i,const.COL_CUM_DST) - Modified_Track_Data(i-1,const.COL_CUM_DST);
end
i=2;
j=2;
while i <= size(track,1)
    while j <= size(Modified_Track_Data,1)
        if(Modified_Track_Data(j,const.COL_CUM_DST) > track(i-1,const.COL_CUM_DST) && Modified_Track_Data(j,const.COL_CUM_DST) <= track(i,const.COL_CUM_DST))
            Modified_Track_Data(j,const.COL_SLOPE) = track(i,const.COL_SLOPE);
            j = j+ 1;
        else
            i = i + 1;
            break;
        end
    end
end
clear i; clear j;

Modified_Track_Data = assign_speed( Modified_Track_Data );

disp( 'Creating simulation input.' );
%% prepare the workspace
% select the sim input from the route matrix and set standard parameters
simin = Modified_Track_Data( :, [(const.COL_CUM_TIME) const.COL_SPEED const.COL_SLOPE const.COL_ACC const.COL_CUM_DST] );

simin(:,1) = simin(:,1)/3600;%sec to hours.. will also be used simulation time

plot_track(track, Modified_Track_Data);

disp( 'Done.' );
disp( '#######################' );