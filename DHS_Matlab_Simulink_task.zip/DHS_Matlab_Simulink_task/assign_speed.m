function track_data = assign_speed(gpx_data)
%ASSIGNSPEED assigns a driving speed to each track point.
% ROUTE = ASSIGNSPEED(TRACK_DATA) extends the gpx data by adding columns
% for velocity, time and acceleration.
%
% GPX_DATA  is a Nx8 array where each row is a track point.
%   Columns 1-3 are the X, Y, and Z coordinates.
%   Columns 4-5 are latitude and longitude
%   Column  6 is the distance between the track point and its predecessor
%   Column  7 is the cumulative track length
%   Column  8 is the slope between the track point and its predecessor.
%
% TRACK_DATA  is a Nx11 array where each row is a track point.
%   Columns 1-3 are the X, Y, and Z coordinates.
%   Columns 4-5 are latitude and longitude
%   Column  6 is the distance between the track point and its predecessor
%   Column  7 is the cumulative track length
%   Column  8 is the slope between the track point and its predecessor
%   Column  9 is the speed in km/h
%   Column  10 is the time in hours
%   Column  11 is the accumulated time in hours
%   Column  12 is the acceleration in m/s^2.
%
% See also loadgpx

% set track_data for speed, time per segment, cumulated time and acceleration to zero
track_data = gpx_data;
track_data(:,const.COL_SPEED:const.COL_ACC) = 0;



% assign speed to each trackpoint
track_data = assign_slope_based_speed( track_data );%assign_fixed_speed( track_data );
track_data = compute_time_and_acceleration( track_data );

end

%% local functions

function out = assign_fixed_speed( in )
    out = in;
    % assign fixed speed of 20 km/h
    out(:,const.COL_SPEED) = 5.556;

end

function out = assign_slope_based_speed( in )
    out = in;
    % assign speed based on the slope of the segment
    out(1,const.COL_SPEED) = 5.556;%20km/hr -> m/s

    for j = 2:size(in,1)
            velocity_temp = sqrt(out(j-1,const.COL_SPEED)^2 + 2*10*(   ( (-9.8)*sin(atan(in(j,const.COL_SLOPE)/100)))) );% v= sqrt(u^2 + 2as)
            if velocity_temp < 3.5
                out(j,const.COL_SPEED) = 3.5;
            elseif velocity_temp > 9
                 out(j,const.COL_SPEED) = 9;
            else 
                out(j,const.COL_SPEED) = velocity_temp;
            end
    end
    
    clear velocity_temp;
    
    for j = 2:size(out,1)
         out(j,const.COL_SPEED) =  out(j,const.COL_SPEED) + 1.0;
    end
end

function out = compute_time_and_acceleration( in )

    out = in;

    out(1,const.COL_SEG_TIME) = 0;  % time
    out(1,const.COL_CUM_TIME) = 0;  % cumulated time
    out(1,const.COL_ACC) = 0;  		% acceleration


    for i = 2:size(in, 1)
        % compute segment time in seconds
        if in(i,const.COL_SPEED) ~= 0
          out(i,const.COL_SEG_TIME) =  2*in(i,const.COL_SEG_DST)* 1000 / (in(i,const.COL_SPEED) + in(i-1,const.COL_SPEED));
        else
        out(i,const.COL_SEG_TIME) = 0;
    end
    % compute accumulated time in seconds
    out(i,const.COL_CUM_TIME) =  out(i-1,const.COL_CUM_TIME) + out(i,const.COL_SEG_TIME);
    % compute acceleration in m/s^2   
    if out(i,const.COL_SEG_TIME) ~= 0
         out(i,const.COL_ACC) = (in(i,const.COL_SPEED) - in(i-1,const.COL_SPEED)) / out(i,const.COL_SEG_TIME)  ;
    else
        out(i,const.COL_ACC) =0;
    end
end

end